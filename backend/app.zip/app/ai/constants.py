QUESTION_MODEL = "gemini-2.5-flash"

EVALUATION_MODEL = "gemini-2.5-flash"

RESUME_MODEL = "gemini-2.5-flash"

MAX_RETRIES = 3

MAX_QUESTIONS = 10

MIN_SCORE = 0

MAX_SCORE = 10