from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database import get_db
from app.dependencies.auth import get_current_user

from app.models.user import User

from app.schemas.interview import (
    InterviewCreate,
    InterviewResponse,
)

from app.schemas.question import QuestionResponse
from app.schemas.answer import AnswerCreate

from app.repositories.interview_repository import (
    get_interviews_by_user,
    get_interview_by_id,
)

from app.services.interview_service import (
    create_new_interview,
    generate_interview_questions,
    get_interview_questions,
    move_to_next_question,
)

from app.services.answer_service import submit_answer

router = APIRouter(
    prefix="/interviews",
    tags=["Interviews"],
)


# ---------------------------------------------------------
# Create Interview
# ---------------------------------------------------------

@router.post(
    "",
    response_model=InterviewResponse,
)
def create_interview(
    interview: InterviewCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):

    return create_new_interview(
        db,
        current_user,
        interview,
    )


# ---------------------------------------------------------
# Get My Interviews
# ---------------------------------------------------------

@router.get(
    "",
    response_model=list[InterviewResponse],
)
def get_my_interviews(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):

    return get_interviews_by_user(
        db,
        current_user.id,
    )


# ---------------------------------------------------------
# Generate AI Questions
# ---------------------------------------------------------

@router.post(
    "/{interview_id}/generate",
    response_model=list[QuestionResponse],
)
def generate_questions(
    interview_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):

    interview = get_interview_by_id(
        db,
        interview_id,
    )

    if interview is None:
        raise HTTPException(
            status_code=404,
            detail="Interview not found",
        )

    if interview.user_id != current_user.id:
        raise HTTPException(
            status_code=403,
            detail="Access denied",
        )

    return generate_interview_questions(
        db,
        interview,
    )


# ---------------------------------------------------------
# Get Interview Questions
# ---------------------------------------------------------

@router.get(
    "/{interview_id}/questions",
    response_model=list[QuestionResponse],
)
def get_questions(
    interview_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):

    interview = get_interview_by_id(
        db,
        interview_id,
    )

    if interview is None:
        raise HTTPException(
            status_code=404,
            detail="Interview not found",
        )

    if interview.user_id != current_user.id:
        raise HTTPException(
            status_code=403,
            detail="Access denied",
        )

    return get_interview_questions(
        db,
        interview_id,
    )


# ---------------------------------------------------------
# Move To Next Question
# ---------------------------------------------------------

@router.post(
    "/{interview_id}/next",
)
def next_question(
    interview_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):

    interview = get_interview_by_id(
        db,
        interview_id,
    )

    if interview is None:
        raise HTTPException(
            status_code=404,
            detail="Interview not found",
        )

    if interview.user_id != current_user.id:
        raise HTTPException(
            status_code=403,
            detail="Access denied",
        )

    return move_to_next_question(
        db,
        interview,
    )


# ---------------------------------------------------------
# Submit Answer
# ---------------------------------------------------------

@router.post(
    "/{interview_id}/answer",
)
def submit_interview_answer(
    interview_id: int,
    answer: AnswerCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):

    interview = get_interview_by_id(
        db,
        interview_id,
    )

    if interview is None:
        raise HTTPException(
            status_code=404,
            detail="Interview not found",
        )

    if interview.user_id != current_user.id:
        raise HTTPException(
            status_code=403,
            detail="Access denied",
        )

    result = submit_answer(
        db,
        interview_id,
        answer,
    )

    if result is None:
        raise HTTPException(
            status_code=404,
            detail="Question not found",
        )

    return result