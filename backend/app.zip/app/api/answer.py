from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database import get_db
from app.dependencies.auth import get_current_user

from app.schemas.answer import AnswerCreate

from app.repositories.interview_repository import (
    get_interview_by_id,
)

from app.services.interview_engine import (
    InterviewEngine,
)

router = APIRouter(
    prefix="/interviews",
    tags=["Answers"],
)


@router.post(
    "/{interview_id}/answer",
)
def submit_interview_answer(
    interview_id: int,
    answer: AnswerCreate,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):

    interview = get_interview_by_id(
        db,
        interview_id,
    )

    if interview is None:
        raise HTTPException(
            status_code=404,
            detail="Interview not found",
        )

    if interview.user_id != current_user.id:
        raise HTTPException(
            status_code=403,
            detail="Access denied",
        )

    result = InterviewEngine.process_answer(
        db,
        interview,
        answer,
    )

    if result is None:
        raise HTTPException(
            status_code=404,
            detail="Question not found",
        )

    return result